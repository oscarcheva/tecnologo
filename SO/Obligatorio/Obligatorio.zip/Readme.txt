Para ejecutar el software de la Cantina embrujada, por favor tenga en cuenta lo siguiente:

1) Disponer de un Sistema operativo Linux para correr el programa.
2) Verificar si tiene instalado un compilador de C corriendo en la termina gcc --version, asi como verificar que tenga instalado make corriendo make --version
3) Si no lo tiene instalado podra instalarlo corriendo (se asume que la distribucion instalada es Ubuntu) sudo apt install build-essential, y luego puede 
efectuar la verificacion indicada en el paso 2.
4) Al confirmar que los tiene instalado, debera correr lo siguientes comando para compilar y preparar los ejecutables, make clean y make.
5) Una vez obtenidos los ejecutables, debera crear terminales separadas y correr en una terminal ./restaurante, en otra terminal correr ./cocineros 
y en la tercera terminal ./mozos